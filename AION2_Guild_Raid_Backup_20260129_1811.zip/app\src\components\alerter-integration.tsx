import React, { useState, useEffect } from 'react';
import { Bell, Link, Check, X, Loader2, Signal, Volume2, RefreshCw, PlayCircle, Wrench } from 'lucide-react';
import { ref, get, child } from 'firebase/database';
import { cn } from '@/lib/utils';
import { alerterDb } from '@/lib/firebase'; // Use the secondary DB

interface AlerterSettings {
    notificationType: 'both' | 'sound' | 'vib' | 'none';
    volume: number;
    alarmStatus: {
        rift: boolean;
        shugo: boolean;
        invasion: boolean;
        nahma: boolean;
        custom: boolean;
    };
    alarmOffsets: number[];
    shugoAlarmOffsets: number[];
    lastSync?: string;
}

const ALARM_SCHEDULE = {
    rift: [0, 2, 4, 6, 8, 10, 12, 14, 16, 18, 20, 22],
    shugo: [20], // Example: 20:00 (Need verification)
    invasion: [19], // Example: 19:00
    nahma: [22], // Example: 22:00
};

export default function AlerterIntegration({ showDiagnostics = false }: { showDiagnostics?: boolean }) {
    const [syncKey, setSyncKey] = useState('');
    const [isConnected, setIsConnected] = useState(false);
    const [isLoading, setIsLoading] = useState(false);
    const [settings, setSettings] = useState<AlerterSettings | null>(null);
    const [error, setError] = useState('');
    const [nextAlarm, setNextAlarm] = useState<string>('계산 중...');

    // Prevent duplicate alerts in the same minute
    const lastTriggeredRef = React.useRef<string | null>(null);
    const audioRef = React.useRef<HTMLAudioElement | null>(null);

    const playAudio = (type: string, minutes: number) => {
        if (!settings) return;

        const folderMap: Record<string, string> = {
            rift: 'rift_shigong',
            shugo: 'shugo',
            invasion: 'chawon',
            nahma: 'nahma'
        };

        const folder = folderMap[type];
        if (!folder) return;

        const path = `/sounds/tts/${folder}/${minutes}min.mp3`;
        console.log(`Playing audio: ${path}`);

        // Stop previous
        if (audioRef.current) {
            audioRef.current.pause();
            audioRef.current.currentTime = 0;
        }

        const audio = new Audio(path);
        audio.volume = settings.volume / 100;

        audio.play().catch(e => {
            console.error("Audio playback failed:", e);
        });

        audioRef.current = audio;
    };

    // Alarm Engine Loop
    useEffect(() => {
        if (!settings || !isConnected) return;

        const checkAlarms = () => {
            const now = new Date();
            const currentHour = now.getHours();

            let minDiff = Infinity;
            let nextStatus = '금일 남은 알람 없음';

            Object.entries(ALARM_SCHEDULE).forEach(([type, hours]) => {
                const alarmType = type as keyof typeof ALARM_SCHEDULE;
                if (!settings.alarmStatus[alarmType as keyof typeof settings.alarmStatus]) return;

                hours.forEach(targetHour => {
                    const targetDate = new Date();
                    targetDate.setHours(targetHour, 0, 0, 0);

                    let diffMs = targetDate.getTime() - now.getTime();
                    let diffMins = Math.ceil(diffMs / 60000);

                    if (diffMins < 0) return; // Passed

                    // Logic for Next Alarm Display
                    if (diffMins < minDiff) {
                        minDiff = diffMins;
                        const label = { rift: '시공', shugo: '슈고', invasion: '침공', nahma: '나흐마' }[alarmType];
                        nextStatus = `${label} ${targetHour}시 (${diffMins}분 전)`;
                    }

                    const offsets = alarmType === 'shugo' ? settings.shugoAlarmOffsets : settings.alarmOffsets;

                    if (offsets.includes(diffMins)) {
                        const triggerKey = `${alarmType}-${targetHour}-${diffMins}`;

                        if (lastTriggeredRef.current !== triggerKey) {
                            // FIRE ALARM
                            const label = {
                                rift: '시공의 균열',
                                shugo: '슈고 페스타',
                                invasion: '차원 침공',
                                nahma: '나흐마'
                            }[alarmType];

                            const text = diffMins === 0
                                ? `${label} 시작 시간입니다!`
                                : `${label}, ${diffMins}분 전입니다.`;

                            triggerAlarm(text, alarmType, diffMins);
                            lastTriggeredRef.current = triggerKey;
                        }
                    }
                });
            });

            setNextAlarm(prev => prev !== nextStatus ? nextStatus : prev);
        };

        const interval = setInterval(checkAlarms, 1000);
        return () => clearInterval(interval);
    }, [settings, isConnected]);

    const triggerAlarm = (text: string, type?: string, diffMins?: number) => {
        if (!settings) return;

        // 1. Browser Notification
        if (settings.notificationType === 'both' || settings.notificationType === 'vib') {
            if (Notification.permission === 'granted') {
                new Notification('아이온2 알리미', { body: text });
            } else if (Notification.permission !== 'denied') {
                Notification.requestPermission().then(permission => {
                    if (permission === 'granted') new Notification('아이온2 알리미', { body: text });
                });
            }
        }

        // 2. Sound (File)
        if (settings.notificationType === 'both' || settings.notificationType === 'sound') {
            if (type && diffMins !== undefined) {
                playAudio(type, diffMins);
            }
        }
    };

    useEffect(() => {
        const savedKey = localStorage.getItem('aion2_alerter_sync_key');
        const localSettings = localStorage.getItem('aion2_alerter_local_settings');

        if (savedKey) {
            setSyncKey(savedKey);
            if (localSettings) {
                // If we have local changes, use them first
                try {
                    setSettings(JSON.parse(localSettings));
                    setIsConnected(true);
                } catch (e) {
                    handleSync(savedKey, true);
                }
            } else {
                // Otherwise fetch from cloud
                handleSync(savedKey, true);
            }
        }

        // Request Notification Permission on mount
        if (Notification.permission !== 'granted' && Notification.permission !== 'denied') {
            Notification.requestPermission();
        }
    }, []);

    // Wrapper to update state AND save to local storage
    const updateSettings = (newSettings: AlerterSettings) => {
        setSettings(newSettings);
        localStorage.setItem('aion2_alerter_local_settings', JSON.stringify(newSettings));
    };

    const handleSync = async (keyInput: string = syncKey, isAuto = false) => {
        const key = keyInput.replace(/\s/g, '').toUpperCase();

        if (key.length < 8) {
            if (!isAuto) setError('키 형식이 올바르지 않습니다.');
            return;
        }

        setIsLoading(true);
        setError('');

        try {
            const snapshotPromise = get(child(ref(alerterDb), `users/${key}`));
            const timeoutPromise = new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), 10000));

            const snapshot: any = await Promise.race([snapshotPromise, timeoutPromise]);

            if (snapshot.exists()) {
                const data = snapshot.val();
                // When syncing from cloud, we update local storage too (Reset)
                updateSettings(data);
                setIsConnected(true);
                localStorage.setItem('aion2_alerter_sync_key', key);
                if (!isAuto) alert('연동 성공! 설정을 불러왔습니다.');
            } else {
                if (!isAuto) setError('유효하지 않은 키입니다. 다시 확인해주세요.');
                setIsConnected(false);
                setSettings(null);
            }
        } catch (e) {
            console.error(e);
            if (!isAuto) setError('연동 중 오류가 발생했습니다.');
        } finally {
            setIsLoading(false);
        }
    };

    const handleDisconnect = () => {
        if (confirm('연동을 해제하시겠습니까?')) {
            localStorage.removeItem('aion2_alerter_sync_key');
            localStorage.removeItem('aion2_alerter_local_settings'); // Clear local settings too
            setSyncKey('');
            setIsConnected(false);
            setSettings(null);
        }
    }

    const toggleAlarm = (key: keyof AlerterSettings['alarmStatus']) => {
        if (!settings) return;
        updateSettings({
            ...settings,
            alarmStatus: {
                ...settings.alarmStatus,
                [key]: !settings.alarmStatus[key]
            }
        });
    };

    const handleTestSound = (arg?: any) => {
        if (!settings) return;

        const text = typeof arg === 'string' ? arg : "슈고 페스타, 5분 전입니다.";

        const speak = (content: string, useDefaultVoice: boolean) => {
            // Cancel previous
            window.speechSynthesis.cancel();

            setTimeout(() => {
                const msg = new SpeechSynthesisUtterance(content);
                msg.volume = settings.volume / 100;
                msg.rate = 1.0;
                msg.pitch = 1.0;

                // Attempt to set voice ONLY if not using default fallback
                if (!useDefaultVoice) {
                    const voices = window.speechSynthesis.getVoices();
                    const korVoice = voices.find(v => v.lang.includes('ko'));
                    if (korVoice) {
                        msg.voice = korVoice;
                        console.log("Using Voice:", korVoice.name);
                    }
                } else {
                    console.log("Using system default voice (Fallback)");
                }

                msg.onstart = () => console.log("TTS Start");
                msg.onerror = (e) => {
                    console.error("TTS Error:", e.error);

                    // Retry Logic: If synthesis-failed and we were using a specific voice, try default
                    if (e.error === 'synthesis-failed' && !useDefaultVoice) {
                        console.warn("TTS Failed with specific voice. Retrying with default...");
                        speak(content, true);
                    } else if (e.error === 'not-allowed') {
                        alert("브라우저가 소리 재생을 차단했습니다. 사이트 설정에서 '소리' 권한을 허용해주세요.");
                    }
                };

                window.speechSynthesis.speak(msg);
            }, 50);
        };

        if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
            speak(text, false);
        } else {
            alert("이 브라우저는 음성 안내를 지원하지 않습니다.");
        }
    };



    return (
        <div className="space-y-6 animate-in fade-in duration-700">
            <div>
                <h2 className="text-4xl font-black text-slate-900 flex items-center gap-3 tracking-tight">
                    <Bell className="text-indigo-500" size={36} />
                    알리미 설정 연동 (Test 단계)
                </h2>
                <div className="flex items-center gap-4 mt-3 font-medium">
                    <p className="text-slate-500 text-sm">
                        연동 키를 입력하면 내 설정을 그대로 불러와 알람을 수신합니다. (원본 설정은 변경되지 않습니다.)
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {/* Left: Connection Panel */}
                <div className="space-y-6">
                    <div className="glass-panel p-8 relative overflow-hidden bg-gradient-to-br from-white to-slate-50">
                        <h3 className="text-xl font-black text-slate-800 mb-6 flex items-center gap-2">
                            <Link size={20} className="text-indigo-500" />
                            동기화 연결
                        </h3>

                        <div className="space-y-6">
                            <div>
                                <label className="block text-xs font-bold text-slate-400 mb-2 pl-1 uppercase tracking-widest">Sync Key</label>
                                <div className="flex gap-2">
                                    <input
                                        type="text"
                                        value={syncKey}
                                        onChange={(e) => setSyncKey(e.target.value.toUpperCase())}
                                        placeholder="A7PV ZAFV"
                                        disabled={isConnected || isLoading}
                                        className={cn(
                                            "w-full bg-white border-2 rounded-2xl px-5 py-4 font-mono font-black text-xl outline-none transition-all placeholder:text-slate-200 tracking-wider shadow-sm",
                                            isConnected
                                                ? "border-green-500 text-green-600 bg-green-50/30"
                                                : "border-slate-100 focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10"
                                        )}
                                    />
                                    {isConnected ? (
                                        <button
                                            onClick={handleDisconnect}
                                            className="px-6 rounded-2xl font-bold bg-white text-red-500 border-2 border-red-50 hover:border-red-100 hover:bg-red-50 transition-all whitespace-nowrap shadow-sm"
                                        >
                                            해제
                                        </button>
                                    ) : (
                                        <button
                                            onClick={() => handleSync()}
                                            disabled={!syncKey || isLoading}
                                            className="px-8 rounded-2xl font-bold bg-indigo-600 text-white shadow-lg shadow-indigo-200 hover:bg-indigo-700 disabled:opacity-50 disabled:shadow-none transition-all whitespace-nowrap active:scale-95"
                                        >
                                            {isLoading ? <Loader2 className="animate-spin" /> : '연동 시작'}
                                        </button>
                                    )}
                                </div>
                                {error && <p className="text-red-500 text-xs font-bold mt-3 ml-2 flex items-center gap-1"><X size={12} /> {error}</p>}
                            </div>

                            <div className="bg-indigo-50/50 rounded-2xl p-5 border border-indigo-50">
                                <h4 className="flex items-center gap-2 text-indigo-900 font-bold text-sm mb-2">
                                    <span className="w-5 h-5 rounded-full bg-indigo-100 flex items-center justify-center text-[10px]">?</span>
                                    연동 키 확인 방법
                                </h4>
                                <p className="text-indigo-700/70 text-xs leading-relaxed pl-7">
                                    아이온2 이벤트 알리미 사이트 방문 시<br />
                                    우측 상단 <strong>[설정] &gt; [기기 연동]</strong>에서 8자리 코드를 확인하실 수 있습니다.
                                </p>
                            </div>

                            <a
                                href="https://aion2-timer.vercel.app/index.html"
                                target="_blank"
                                rel="noopener noreferrer"
                                className="flex items-center justify-center gap-2 w-full py-4 rounded-2xl border-2 border-indigo-100 text-indigo-400 font-bold hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-200 transition-all group"
                            >
                                <span className="group-hover:scale-110 transition-transform">🔗</span>
                                아이온2 이벤트 알리미 바로가기
                            </a>
                        </div>
                    </div>
                </div>

                {/* Right: Interactive Settings Dashboard */}
                <div className="space-y-6">
                    {isConnected && settings ? (
                        <div className="glass-panel p-8 animate-in slide-in-from-bottom-4 duration-500 border-indigo-100 bg-white/80 relative shadow-xl shadow-indigo-100/20 backdrop-blur-xl">
                            {/* Header */}
                            <div className="flex items-center justify-between mb-8">
                                <h3 className="text-xl font-black text-slate-800 flex items-center gap-2">
                                    <Signal size={20} className="text-green-500" />
                                    통합 알람 제어
                                </h3>
                                <div className="flex gap-2">
                                    <button
                                        onClick={() => playAudio('shugo', 5)}
                                        className="px-4 py-2 rounded-lg bg-white border border-slate-200 text-slate-600 font-bold text-xs shadow-sm hover:bg-slate-50 active:scale-95 transition-all flex items-center gap-1.5"
                                    >
                                        <PlayCircle size={14} className="text-indigo-500" />
                                        소리 테스트
                                    </button>
                                    <button
                                        onClick={() => handleSync(syncKey, false)}
                                        className="px-4 py-2 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-600 font-bold text-xs shadow-sm hover:bg-indigo-100 active:scale-95 transition-all flex items-center gap-1.5"
                                    >
                                        <RefreshCw size={14} className={isLoading ? "animate-spin" : ""} />
                                        불러오기
                                    </button>
                                </div>
                            </div>

                            <div className="space-y-10">
                                {/* 1. Notification Mode (Tabs) */}
                                <div>
                                    <label className="block text-xs font-bold text-slate-400 mb-3 pl-1 uppercase tracking-widest flex items-center gap-2">
                                        <Bell size={12} /> 알람 방식
                                    </label>
                                    <div className="bg-slate-100 p-1.5 rounded-2xl flex gap-1">
                                        <ModeSelector
                                            label="알림+소리"
                                            icon="📢"
                                            active={settings.notificationType === 'both'}
                                            onClick={() => updateSettings({ ...settings, notificationType: 'both' })}
                                        />
                                        <ModeSelector
                                            label="소리만"
                                            icon="🔊"
                                            active={settings.notificationType === 'sound'}
                                            onClick={() => updateSettings({ ...settings, notificationType: 'sound' })}
                                        />
                                        <ModeSelector
                                            label="알림만"
                                            icon="💬"
                                            active={settings.notificationType === 'vib'}
                                            onClick={() => updateSettings({ ...settings, notificationType: 'vib' })}
                                        />
                                        <ModeSelector
                                            label="끄기"
                                            icon="🔕"
                                            active={settings.notificationType === 'none'}
                                            isDestructive
                                            onClick={() => updateSettings({ ...settings, notificationType: 'none' })}
                                        />
                                    </div>
                                </div>

                                {/* 2. Volume Slider */}
                                <div>
                                    <div className="flex justify-between items-center mb-4 px-1">
                                        <label className="text-xs font-bold text-slate-400 uppercase tracking-widest flex items-center gap-2">
                                            <Volume2 size={12} /> 알람 볼륨
                                        </label>
                                        <div className="px-3 py-1 rounded-lg bg-indigo-50 text-indigo-600 text-sm font-black tabular-nums">
                                            {settings.volume}%
                                        </div>
                                    </div>
                                    <div className="relative h-6 flex items-center">
                                        <div className="absolute w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                                            <div
                                                className="h-full bg-gradient-to-r from-indigo-400 to-indigo-600 transition-all duration-100"
                                                style={{ width: `${settings.volume}%` }}
                                            />
                                        </div>
                                        <input
                                            type="range"
                                            min="0"
                                            max="100"
                                            step="1"
                                            value={settings.volume}
                                            onChange={(e) => updateSettings({ ...settings, volume: parseInt(e.target.value) })}
                                            className="absolute w-full h-full opacity-0 cursor-pointer"
                                        />
                                        <div
                                            className="absolute w-5 h-5 bg-white border-2 border-indigo-500 rounded-full shadow-md pointer-events-none transition-all duration-100"
                                            style={{ left: `calc(${settings.volume}% - 10px)` }}
                                        />
                                    </div>
                                </div>

                                {/* 3. Active Alarms & Details (Consolidated) */}
                                <div>
                                    <label className="block text-xs font-bold text-slate-400 mb-3 pl-1 uppercase tracking-widest flex items-center gap-2">
                                        <Check size={12} /> 알람 대상
                                    </label>

                                    {/* Checkbox Row */}
                                    <div className="flex flex-wrap gap-4 mb-6 px-1">
                                        <CompactToggle label="시공" active={settings.alarmStatus?.rift} onClick={() => toggleAlarm('rift')} />
                                        <CompactToggle label="슈고" active={settings.alarmStatus?.shugo} onClick={() => toggleAlarm('shugo')} />
                                        <CompactToggle label="침공" active={settings.alarmStatus?.invasion} onClick={() => toggleAlarm('invasion')} />
                                        <CompactToggle label="나흐마" active={settings.alarmStatus?.nahma} onClick={() => toggleAlarm('nahma')} />
                                        <CompactToggle label="커스텀" active={settings.alarmStatus?.custom} onClick={() => toggleAlarm('custom')} />
                                    </div>

                                    {/* Tree View Details */}
                                    <div className="space-y-1 pl-2">
                                        {/* Rift Details */}
                                        <TreeItem
                                            label="시공"
                                            active={settings.alarmStatus?.rift}
                                            times={settings.alarmOffsets}
                                        />

                                        {/* Shugo Details */}
                                        <TreeItem
                                            label="슈고"
                                            active={settings.alarmStatus?.shugo}
                                            times={settings.shugoAlarmOffsets}
                                        // Removed isAmber for consistency
                                        />

                                        {/* Invasion Details */}
                                        <TreeItem
                                            label="침공"
                                            active={settings.alarmStatus?.invasion}
                                            times={settings.alarmOffsets}
                                        />

                                        {/* Nahma Details - Fixed to 시작 시 */}
                                        <TreeItem
                                            label="나흐마"
                                            active={settings.alarmStatus?.nahma}
                                            customContent={
                                                <span className="px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-xs font-bold text-slate-600">
                                                    시작 시
                                                </span>
                                            }
                                        />

                                        {/* Custom Details */}
                                        <TreeItem
                                            label="커스텀"
                                            active={settings.alarmStatus?.custom}
                                            customContent={
                                                <span className="px-2 py-0.5 rounded-md bg-slate-100 border border-slate-200 text-xs font-bold text-slate-600">
                                                    1개 활성
                                                </span>
                                            }
                                            isLast
                                        />
                                    </div>

                                    {/* 4. Diagnostics (Hidden by default) */}
                                    {showDiagnostics && (
                                        <div className="animate-in fade-in slide-in-from-bottom-2 duration-500">
                                            <div className="flex justify-between items-end mb-3">
                                                <label className="text-xs font-bold text-slate-400 pl-1 uppercase tracking-widest flex items-center gap-2">
                                                    <Wrench size={12} /> 알람 진단
                                                </label>
                                                <span className="text-xs font-bold text-indigo-500 bg-indigo-50 px-2 py-1 rounded-md">
                                                    {nextAlarm}
                                                </span>
                                            </div>
                                            <div className="bg-slate-50 p-4 rounded-2xl space-y-3 border border-slate-100">
                                                <p className="text-xs text-slate-400 font-medium flex items-center gap-1">
                                                    <PlayCircle size={10} />
                                                    강제 알람 실행 (소리 및 알림 테스트)
                                                </p>
                                                <div className="grid grid-cols-2 gap-2">
                                                    <button onClick={() => playAudio('shugo', 5)} className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-100 transition-all text-left shadow-sm group">
                                                        <span className="opacity-50 group-hover:opacity-100 mr-2">🐹</span>
                                                        슈고 5분전
                                                    </button>
                                                    <button onClick={() => playAudio('rift', 5)} className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-100 transition-all text-left shadow-sm group">
                                                        <span className="opacity-50 group-hover:opacity-100 mr-2">⚡</span>
                                                        시공 5분전
                                                    </button>
                                                    <button onClick={() => playAudio('invasion', 5)} className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-100 transition-all text-left shadow-sm group">
                                                        <span className="opacity-50 group-hover:opacity-100 mr-2">⚔️</span>
                                                        침공 5분전
                                                    </button>
                                                    <button onClick={() => playAudio('nahma', 0)} className="px-3 py-2 bg-white border border-slate-200 rounded-xl text-xs font-bold text-slate-600 hover:bg-indigo-50 hover:text-indigo-600 hover:border-indigo-100 transition-all text-left shadow-sm group">
                                                        <span className="opacity-50 group-hover:opacity-100 mr-2">👑</span>
                                                        나흐마 시작
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    )}


                                </div>
                            </div>
                        </div>
                    ) : (
                        <div className="glass-panel p-8 flex flex-col items-center justify-center h-full min-h-[500px] text-slate-300 gap-6 border-dashed border-2 bg-transparent">
                            <div className="p-8 rounded-full bg-slate-50 animate-pulse">
                                <Link size={64} className="opacity-20" />
                            </div>
                            <div className="text-center space-y-1">
                                <p className="text-lg font-black text-slate-400">연동 대기 중</p>
                                <p className="text-sm font-medium opacity-60">좌측 패널에서 Sync Key를 입력해주세요</p>
                            </div>
                        </div>
                    )}
                </div>
            </div>
        </div >
    );
}

// --- Helper Components for Premium UI ---

function ModeSelector({ label, icon, active, isDestructive, onClick }: any) {
    return (
        <button
            onClick={onClick}
            className={cn(
                "flex-1 flex flex-col items-center justify-center gap-1 py-3 rounded-xl transition-all duration-200 font-bold text-xs",
                active
                    ? "bg-white text-indigo-600 shadow-md shadow-slate-200 scale-[1.02]"
                    : "text-slate-400 hover:bg-slate-200/50 hover:text-slate-600",
                active && isDestructive && "text-red-500"
            )}
        >
            <span className="text-lg mb-0.5">{icon}</span>
            <span>{label}</span>
        </button>
    )
}

function CompactToggle({ label, active, onClick }: any) {
    return (
        <button
            onClick={onClick}
            className="flex items-center gap-1.5 transition-all outline-none group"
        >
            <div className={cn(
                "w-5 h-5 flex items-center justify-center border transition-all rounded-[4px]", // Square shape
                active
                    ? "bg-green-500 border-green-500 text-white shadow-sm" // Green Check
                    : "bg-white border-red-200 text-red-500 hover:border-red-300" // Red X outline
            )}>
                {active ? <Check size={14} strokeWidth={4} /> : <X size={14} strokeWidth={4} />}
            </div>
            <span className={cn(
                "text-sm font-bold transition-colors",
                active ? "text-slate-700" : "text-slate-400"
            )}>
                {label}
            </span>
        </button>
    );
}

function TreeItem({ label, active, times, isAmber, customContent, isLast }: any) {
    return (
        <div className="flex items-start gap-3 relative h-10">
            {/* Tree Connector L-shape */}
            <div className="absolute left-0 top-0 w-4 h-full">
                <div className="absolute left-0 top-0 w-[2px] h-full bg-slate-100" />
                <div className="absolute left-0 top-[50%] w-3 h-[2px] bg-slate-100" />
            </div>

            <div className="ml-6 flex items-center justify-between w-full h-full pr-2">
                <span className={cn(
                    "text-sm font-bold transition-colors w-16 text-right",
                    active ? "text-slate-600" : "text-slate-300" // Removed line-through as per request to "show settings as is"
                )}>
                    {label}:
                </span>

                <div className={cn(
                    "flex items-center justify-end gap-1.5 flex-1 flex-wrap transition-opacity duration-200",
                    !active && "opacity-60 grayscale"
                )}>
                    {/* Always render content regardless of active state */}
                    {customContent ? customContent : (
                        times?.length > 0 ? times.map((t: number) => (
                            <span key={t} className={cn(
                                "px-2 py-0.5 rounded-md border text-xs font-bold shadow-sm",
                                isAmber
                                    ? "bg-amber-50 border-amber-100 text-amber-600"
                                    : "bg-slate-100 border-slate-200 text-slate-600"
                            )}>
                                {t === 0 ? "시작 시" : `${t}분 전`}
                            </span>
                        )) : <span className="text-xs text-slate-300">-</span>
                    )}
                </div>
            </div>
        </div>
    );
}
